package proj.tests;

import org.junit.Test;

public class Main1Test {
	
	@Test
	public void testAlwaysPasses() {
		// This test always passes
	}
}
