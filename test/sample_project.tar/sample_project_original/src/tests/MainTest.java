package sample_project_original.src.tests;

import static org.junit.Assert.fail;

import org.junit.Test;

public class MainTest {
	
	@Test
	public void testNothing() {
		// Test nothing
	}
	
	@Test
	public void testAlwaysFails() {
		// This test always fails
		fail("This test always fails.");
	}
}
