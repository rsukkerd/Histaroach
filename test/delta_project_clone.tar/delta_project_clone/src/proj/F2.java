package proj;

public class F2 {

	public boolean m() {
		F1 f1 = new F1();
		return f1.m() && f1.m2();
	}

}
