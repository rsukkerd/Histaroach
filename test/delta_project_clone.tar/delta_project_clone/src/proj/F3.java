package proj;

public class F3 {

	public boolean m() {
		return false;
	}

}
