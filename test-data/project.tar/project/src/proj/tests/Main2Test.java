package proj.tests;

import static org.junit.Assert.fail;

import org.junit.Test;

public class Main2Test {
	
	@Test
	public void testAlwaysPasses() {
		// This test always passes
	}

	@Test
	public void testAlwaysFails() {
		// This test always fails
		fail("This test always fails.");
	}
}
