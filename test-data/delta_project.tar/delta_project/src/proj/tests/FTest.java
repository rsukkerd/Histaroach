package proj.tests;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import proj.F1;
import proj.F2;
import proj.F3;

public class FTest {
	
	@Test
	public void testF1() {
		F1 f1 = new F1();
		assertTrue(f1.m());
	}

	@Test
	public void testF2() {
		F2 f2 = new F2();
		assertTrue(f2.m());
	}

	@Test
	public void testF3() {
		F3 f3 = new F3();
		assertTrue(f3.m());
	}
}
