package proj;

public class F1 {

	public boolean m() {
		return true;
	}
	
	public boolean m2() {
		return true;
	}
}
